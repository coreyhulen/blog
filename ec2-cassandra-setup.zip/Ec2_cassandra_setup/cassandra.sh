#!/bin/bash -e

#
# EarnstoneUtils: Earnstone Utilities.
# 
# Copyright 2010 Corey Hulen, Earnstone Corporation
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License. 
#
 
export DEBIAN_FRONTEND=noninteractive

echo "deb http://us.ec2.archive.ubuntu.com/ubuntu/ karmic multiverse" | sudo -E tee -a /etc/apt/sources.list
echo "deb-src http://us.ec2.archive.ubuntu.com/ubuntu/ karmic multiverse" | sudo -E tee -a /etc/apt/sources.list	
echo "deb http://us.ec2.archive.ubuntu.com/ubuntu/ karmic-updates multiverse" | sudo -E tee -a /etc/apt/sources.list
echo "deb-src http://us.ec2.archive.ubuntu.com/ubuntu/ karmic-updates multiverse" | sudo -E tee -a /etc/apt/sources.list
 
# run an update and upgarde
sudo -E apt-get update	-y	
sudo -E apt-get upgrade -y

# Install munin node to monitor this instance
sudo -E apt-get install -y munin-node
# Replace the Munin cpu plugin with one that recognizes "steal" CPU cycles
sudo -E curl -o /usr/share/munin/plugins/cpu https://anvilon.s3.amazonaws.com/web/20081117-munin/cpu
sudo -E curl -o /usr/share/munin/plugins/plugin.sh https://anvilon.s3.amazonaws.com/web/20081117-munin/plugin.sh

#Install the casandra munin plugins for monitoring a cassandra server.
sudo -E apt-get install -y git-core
git clone http://github.com/jamesgolick/cassandra-munin-plugins.git
chmod u+x ~/cassandra-munin-plugins/jmx_
sudo -E ln -s ~/cassandra-munin-plugins/jmx_ /etc/munin/plugins/jvm_cpu
sudo -E ln -s ~/cassandra-munin-plugins/jmx_ /etc/munin/plugins/jvm_memory
sudo -E ln -s ~/cassandra-munin-plugins/jmx_ /etc/munin/plugins/ops_pending
#ifconfig  | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk '{ print $1}'

sudo -E /etc/init.d/munin-node restart
	
#install the ntp time server
sudo -E apt-get install -y ntp


# install java 6 runtime
echo "sun-java6-jdk shared/accepted-sun-dlj-v1-1 boolean true" | sudo -E debconf-set-selections	
sudo -E apt-get install -y sun-java6-jdk
echo "export JAVA_HOME=/usr/lib/jvm/java-6-sun" | sudo -E tee -a ~/.bashrc		

 
# install ant
sudo -E apt-get install -y ant


# configure the cassandra default directories to point to and use the 
# epherimal storage located at /mnt
sudo -E mkdir /var/lib/cassandra
sudo -E chown ubuntu /var/lib/cassandra
sudo -E mkdir /var/log/cassandra
sudo -E chown ubuntu /var/log/cassandra
mkdir /var/lib/cassandra/commitlog /var/lib/cassandra/data
sudo -E mkdir /mnt/cassandra
sudo -E chown ubuntu /mnt/cassandra
mkdir /mnt/cassandra/commitlog /mnt/cassandra/data /mnt/cassandra/logs
echo "/mnt/cassandra/logs /var/log/cassandra     none bind" | sudo -E tee -a /etc/fstab
sudo -E mount /var/log/cassandra
echo "/mnt/cassandra/commitlog /var/lib/cassandra/commitlog     none bind" | sudo -E tee -a /etc/fstab
sudo -E mount /var/lib/cassandra/commitlog
echo "/mnt/cassandra/data /var/lib/cassandra/data     none bind" | sudo -E tee -a /etc/fstab
sudo -E mount /var/lib/cassandra/data


# download and untar cassandra in the users home directory
wget -q http://www.apache.org/dist/cassandra/0.6.2/apache-cassandra-0.6.2-bin.tar.gz
tar -zxf apache-cassandra-0.6.2-bin.tar.gz
echo "export CASSANDRA_HOME=~/apache-cassandra-0.6.2" | sudo -E tee -a ~/.bashrc
rm apache-cassandra-0.6.2-bin.tar.gz

#copy over the storage config if one was provided.
if [ -e ~/storage-conf.xml ]; then
    mv ~/storage-conf.xml ~/apache-cassandra-0.6.2/conf
fi

# setup a cron job to run the cassandra snapshot every morning at 1 am.
mkdir ~/cron
mkdir ~/cron/logs
cat << CRONCASSSNAP > ~/cron/cass_snapshot.sh
#!/bin/bash -e
echo -n "Running cassandra cron snapshot job "
date
\$CASSANDRA_HOME/bin/nodetool snapshot -h 127.0.0.1 -p 8080
CRONCASSSNAP
chmod u+x ~/cron/cass_snapshot.sh
echo "0 1 * * * ~/cron/cass_snapshot.sh >> ~/cron/logs/cass_snapshot.log" | tee -a cron_jobs.txt
crontab cron_jobs.txt

# configure and mount the EBS drive if one was created.
if [ -e /dev/sdh ]; then
    sudo -E apt-get install -y xfsprogs
    sudo -E mkfs.xfs /dev/sdh
    echo "/dev/sdh /backupvol xfs noatime 0 0" | sudo -E tee -a /etc/fstab
    sudo -E mkdir -m 000 /backupvol
    sudo -E mount /backupvol    
    
    # create a location for the cassandra backups
    sudo -E mkdir /backupvol/cassandra
    sudo -E chown ubuntu /backupvol/cassandra
    mkdir /backupvol/cassandra/commitlog /backupvol/cassandra/data    

    #setup a cron job to copy the snapshots to the EBS drive
    cat << CRONCOPYTOEBS > ~/cron/cass_move_to_ebs.sh
    #!/bin/bash -e
    echo -n "Copying cassandra snapshots to EBS "
    date
    DIR="/var/lib/cassandra/data"
    for i in "\$DIR"/*
    do
    if [ -d "\$i/snapshots" ]; then        
        basefile=\${i##*/}
	MAX=0

        # find the latest snapshot based on timestamp
        for j in "\$i/snapshots"/*
        do
            basetimestamp=\${j##*/}                         
            if [ \$basetimestamp -gt \$MAX ]; then 
                MAX=\$basetimestamp
            fi            
        done

        # copy the latest snapshots from the epherimal drive
        # to the EBS drive
        copyto=/backupvol/cassandra/data/\$basefile/snapshots
        copyfrom=\$i/snapshots/\$MAX
        mkdir -p \$copyto/\$MAX
        cp -r \$copyfrom \$copyto

        # remove all the other snapshots except the
        # latest snapshot that was copied over
        for k in "\$copyto"/*
        do
            if [ "\$k" != "\$copyto/\$MAX" ]; then
                rm -r \$k
            fi        
        done
    fi

    # cleanup the snapshots on the epherimal drives
    #\$CASSANDRA_HOME/bin/nodetool clearsnapshot -h 127.0.0.1 -p 8080
    done    
CRONCOPYTOEBS
    chmod u+x ~/cron/cass_move_to_ebs.sh
    echo "0 3 * * 0 ~/cron/cass_move_to_ebs.sh >> ~/cron/logs/cass_move_to_ebs.log" | tee -a cron_jobs.txt
    crontab cron_jobs.txt

    #setup a cron job to backup the EBS drive one a week on Sunday
fi

rm cron_jobs.txt

echo "WARN: cassandra was not started. You must upload your storage-conf.xml"
echo "      and start cassandra from CASSANDRA_HOME/bin"





