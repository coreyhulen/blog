
DESCRIPTION README_stress_large_ebs_raid.txt
=========================================================================
This readme will walk you through the steps we used to create this
stress test using large EC2 instances with ebs storage.

**NOTE**:  Refer to the README_stress_small_ebs_raid.txt for more information
           on setting up a ebs raid drive.

Single Node Test
=========================================================================

Step 1: 
   Create a large instance running cassandra.
   Create a small instance running cassandra.  This will create 3 ebs drives of size 12 GB. 

   user@localmachine:~$ ./setup_box.sh -p "/home/user/path/YourPemKeyFile.pem" -t m1.large -a ami-55739e3c -s 16 -n 3 cassandra-ebs-raid.sh storage-conf-large.xml


Step 2:
   Lets change the memory setting for the large instnace.
   You should be logged into the remote machine already.

   ubuntu@domU-XX-XX-XX-XX-XX-a1:~$ cd ~/apache-cassandra-0.6.2
   ubuntu@domU-XX-XX-XX-XX-XX-a1:~$ nano bin/cassandra.in.sh
  
   change the line from '-Xms256M \' to '-Xms1024M \'
   and
   change the line from '-Xmx1G \' to '-Xmx5G \'
  
 
Step 3:
   Now continue from step 2 in README_stress_small_epherimal.txt.  Notice the only difference is the instance and type and a few paramter tweeks.

   1) When you run a stress test x5 the number of threads for the test so '--threads 10' becomes '--threads 50'
   
   2) Also multiple the number of rows x4 for '5000000' becomes '20000000'
  
   3) When refering to creating client machines for testing make sure to add the '-t m1.large -a ami-55739e3c' paramters to the command line
      So you can create a large client for testing.


Notes:

   After you load the data the node should report approx 9.16 GB using ring.
   Check top to make sure the cassandra process is idle.  Sometimes it will start 
   compacting causing the cpu% to high until it finishes.  Make sure to check
   in between each test and wait for idle before starting next test.  I can take
   several minutes (5-10) for compaction.

