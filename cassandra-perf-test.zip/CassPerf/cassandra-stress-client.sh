#!/bin/bash -e

#
# EarnstoneUtils: Earnstone Utilities.
# 
# Copyright 2010 Corey Hulen, Earnstone Corporation
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License. 
#
 
export DEBIAN_FRONTEND=noninteractive

echo "deb http://us.ec2.archive.ubuntu.com/ubuntu/ karmic multiverse" | sudo -E tee -a /etc/apt/sources.list
echo "deb-src http://us.ec2.archive.ubuntu.com/ubuntu/ karmic multiverse" | sudo -E tee -a /etc/apt/sources.list	
echo "deb http://us.ec2.archive.ubuntu.com/ubuntu/ karmic-updates multiverse" | sudo -E tee -a /etc/apt/sources.list
echo "deb-src http://us.ec2.archive.ubuntu.com/ubuntu/ karmic-updates multiverse" | sudo -E tee -a /etc/apt/sources.list
 
# run an update and upgarde
sudo -E apt-get update	-y	
sudo -E apt-get upgrade -y

# Install munin node to monitor this instance
sudo -E apt-get install -y munin-node
# Replace the Munin cpu plugin with one that recognizes "steal" CPU cycles
sudo -E curl -o /usr/share/munin/plugins/cpu https://anvilon.s3.amazonaws.com/web/20081117-munin/cpu
sudo -E curl -o /usr/share/munin/plugins/plugin.sh https://anvilon.s3.amazonaws.com/web/20081117-munin/plugin.sh

sudo -E apt-get install -y apache2 munin

sudo -E /etc/init.d/munin-node restart

# download and install the thrift python interfaces
cd ~
wget -q http://www.apache.org/dist/incubator/thrift/0.2.0-incubating/thrift-0.2.0-incubating.tar.gz
tar -zxf thrift-0.2.0-incubating.tar.gz
cd ~/thrift-0.2.0
#sudo apt-get install -y libboost-dev libevent-dev python-dev automake pkg-config libtool flex bison
sudo apt-get install -y libboost-dev libevent-dev python-dev automake pkg-config libtool flex bison
./bootstrap.sh
./configure
make
sudo make install
cd ./lib/py
make
sudo make install
echo "export PYTHONPATH=/usr/lib/python2.6/site-packages" | sudo -E tee -a ~/.bashrc

source ~/.bashrc
	
# download and untar cassandra source in the users home directory
cd ~
wget -q http://www.apache.org/dist/cassandra/0.6.2/apache-cassandra-0.6.2-src.tar.gz
tar -zxf apache-cassandra-0.6.2-src.tar.gz
cd ~/apache-cassandra-0.6.2-src/interface
thrift --gen py -o thrift cassandra.thrift
#ant gen-thrift-py








