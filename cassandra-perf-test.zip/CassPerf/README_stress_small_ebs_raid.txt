
DESCRIPTION README_stress_small_ebs_raid.txt
=========================================================================
This readme will walk you through the steps we used to create this
stress test using small EC2 instances with EBS raid storage.


Single Node Test 2 disks in Raid 0
=========================================================================

Step 1: 
   Create a small instance running cassandra.  This will create 3 ebs drives of size 12 GB.  
   Why 12 GB?  because it's easy to find and differiantiate from my other drives 
   in the AWS console and delete them :)
   One drive will just be plain old XFS drive for the commit logs since the first couple of
   test look like writes is CPU bound not IO bound.  The other 2 drives will be configured 
   as raid 0 drive at /dev/md0

   user@localmachine:~$ ./setup_box.sh -p "/home/user/path/YourPemKeyFile.pem" -s 12 -n 3 cassandra-ebs-raid.sh storage-conf-small.xml

   verify the drives were created succefully by runnign the command

   ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ df -h
   /dev/sdf               12G  4.2M   12G   1% /disk1
   /dev/md0               24G  4.6M   24G   1% /disk2

   I noticed that on some instances (I cannot find the reference now, but I thought it was a kernel bug in 9.10 on ec2) the
   raid0 drive doesn't survives reboot.  Make sure the /dev/md0 drive exists and is mapped to /disk2
   if it doesn't exists running the command below will re-attach it.

      ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ sudo mdadm --assemble --scan
   

Step 2:
   Now continue from step 2 in README_stress_small_epherimal.txt.  Notice the only difference is the extra drives.
   /var/lib/cassandra/commitlog is mapped to is own drive at /needdrivehere
   /var/lib/cassandra/data is mapped to the raided drives at /raiddrive/cassandra/data



Single Node Test 4 disks in Raid 0
=========================================================================

Change the -n paramater above to 5.  This wil equal 1 drive for the commitlog and 4 drives in raid 0 for the data drive.
