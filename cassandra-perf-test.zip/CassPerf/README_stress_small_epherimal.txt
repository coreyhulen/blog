
DESCRIPTION README_stress_small_epherimal.txt
=========================================================================
This readme will walk you through the steps we used to create this
stress test using small EC2 instances with only epherimal storage.


Single Node Test
=========================================================================

Step 1: 
   Create a small instance running cassandra

   user@localmachine:~$ ./setup_box.sh -p "/home/user/path/YourPemKeyFile.pem" cassandra-epherimal.sh storage-conf-small.xml

Step 2: 
   Start the cassandra instance on the remote machine.  Notice the setup_box.sh script should have
   logged you into the machine.
 
   ubuntu@domU-XX-XX-XX-XX-XX-a1:~$ cd ~/apache-cassandra-0.6.2
   ubuntu@domU-XX-XX-XX-XX-XX-a1:~$ ./bin/cassandra -p pid.txt

Step 3: 
   Setup 1 client stress box.  Please refer to README_client.txt

Step 4: 
   Run the following tests from the client stress boxes to warm the servers
   
   ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ cd ~/apache-cassandra-0.6.2-src/contrib/py_stress
   ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ python stress.py --operation insert --num-keys 100000 --nodes 10.206.117.164 --family-type regular  --threads 15

Step 5: 
   Run the following tests from the client stress boxes (one at a time).

   Note: The test needs to be larger than the available RAM on the machine.  
   We notice smaller tests performing really well 10x when the test data set was small.
   The key cache appears to help, but also We believe the OS is doing a lot behind
   the scene because small read tests with only 1M rows of data (350 MB) didn't utilize the disk 
   more than 10%.

   Test Writes (Should take approx 1 hrs):
   ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ python stress.py --operation insert --num-keys 5000000 --nodes 10.206.117.164 --family-type regular --threads 30
   Note:  even though the test finishes in 1 hr you may need to wait an extra couple of minutes
          for the box to go back down to idle cpu.
          After the write finishes the box should have 2.29 GB (or around there).


   Test Reads (Should take approx too long):
   ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ python stress.py --operation read --num-keys 5000000 --nodes 10.206.117.164 --family-type regular --threads 10
   Since this test looks like it will take approx 10 hrs to finish we only let it
   run for 1 hr to capture our results.  Because of the way the py_stress script
   is writting we couldn't just change the number of keys to say something like 500K
   to make the test complete in an hour.
   You can also run the test with the --random flag  since so little of the 
   data sets fits in the cached key space we found very little difference
   between this setting and -stdev

   Test Read/Writes (Should take approx 1 hr):  
       This is the 50/50 test.  You need to try and start both these tests around the 
       same time (+/- 5s).  I typically do it from two different shell windows.  To
       calculate the results for this test you need to average the two outputs together.
       Notice the read write test will finish at different times.  So we look for the
       test that finished first and use that time index to look at the last time of the
       other scripts.  For example in the below test writes will finish in about 10% of
       the time of the read test.  Then the read test has the whole box to itself and the
       read throughput will start to climb again because the write test has finished.

   ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ python stress.py --operation insert --num-keys 5000000 --nodes 10.206.117.164 --family-type regular --threads 30
   ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ python stress.py --operation read --num-keys 5000000 --nodes 10.206.117.164 --family-type regular --threads 10

   After the write portion finishes in about an hour you should have  4.52 GB of data.

   Notes:
   Remember if you configured munin you can monitor the servers by hitting http://domU-XX-XX-XX-XX-XX-c1.publicdns/munin or montior
   the nodes using top to see if CPU is saturated or in IO wait time. or you can monitor the node with a command like the one
   below which will capture top command output every 60 seconds for 25 iterations (or 25 minutes) on pid 1251 or the cassandra process.  You
   can easily find the process id by invoking the 'jps' command to show the java processes.

   ubuntu@domU-XX-XX-XX-XX-XX-a1:~$ top -b -n30 -p 1251 -d 60 > run1.txt &

   Also you can use iostat to see the drive performance.  with 'iostat -x 5' looking at the utilzie and await columms.
   Also vmstat is good to check sawpiness with 'vmstat 5' looking at the so si columns.

Step 6:
   Re-run the tests.
   I stopped the cassandra server and removed the /var/lib/cassandra directory and restarted the tests.
   I averaged the tests from 2 complete runs of Step 5. 
   
3 Node Test
=========================================================================

Step 1: 
     Configure the first node using steps 1-3 of the Single Node Test.
     Except set the starting token in the storage-conf.xml to (see below).  If you
     are reusing the server from the single node test then make sure to stop it
     and delete the /var/lib/cassandra directory and re-start.

Step 2:  
     Configure a second and third server in similar fashion to steps 1-2 of the Single Node Test, but
     make sure to change the <Seed>127.0.0.1</Seed> in stoarge-conf.xml to point to the
     first machine and set the starting token to  (seed below).

     Note:  We set the token based on the formula of i × (2^127 ÷ N), or 1 × (2^127 ÷ 3),
     2 × (2^127 ÷ 3), and 3 × (2^127 ÷ 3)

     Initial Tokens:
         Node1: 56713727820156410577229101238628035242
         Node2: 113427455640312821154458202477256070485
         Node3: 170141183460469231731687303715884105728


     Verify the cluster is up and running correctly by using the nodetool ring command.

Step 3:
      Run the following tests from the client stress boxes to warm the servers

     ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ cd ~/apache-cassandra-0.6.2-src/contrib/py_stress
     ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ python stress.py --operation insert --num-keys 100000 --nodes 10.206.117.164,10.206.99.35,10.254.173.157 --family-type regular --random --threads 15
          
Step 4:
     Run the following tests from the client stress boxes.  Always try to start the client scripts around the same time (+/- 5s).

     Note: You should peridoically check the cluster using the nodetool ring command to make sure it
           is well balanced.  It should be well balanced unless something was missed configured.

           It is also helpful to run the nodetool tpstat command peridically to make sure nothing is backing up.


     Test Writes (Should take approx 12 mins):
     ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ python stress.py --operation insert --num-keys 1000000 --nodes 10.206.117.164,10.206.99.35,10.254.173.157 --family-type regular --random --threads 60 
     On second client test machine run
     ubuntu@domU-XX-XX-XX-XX-XX-c2:~$ python stress.py --operation insert --num-keys 1000000 --nodes 10.206.117.164,10.206.99.35,10.254.173.157 --family-type regular --random --threads 60


     Test Reads (Should take approx 20 mins):
     ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ python stress.py --operation read --num-keys 1000000 --nodes 10.206.117.164,10.206.99.35,10.254.173.157 --family-type regular --random --threads 60     
     On second client test machine run
     ubuntu@domU-XX-XX-XX-XX-XX-c2:~$ python stress.py --operation read --num-keys 1000000 --nodes 10.206.117.164,10.206.99.35,10.254.173.157 --family-type regular --random --threads 60


     Test Read/Writes (Should take approx 20 mins):  
     ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ python stress.py --operation insert --num-keys 1000000 --nodes 10.206.117.164,10.206.99.35,10.254.173.157 --family-type regular --random --threads 80 
     On second client test machine run
     ubuntu@domU-XX-XX-XX-XX-XX-c2:~$ python stress.py --operation read --num-keys 1000000 --nodes 10.206.117.164,10.206.99.35,10.254.173.157 --family-type regular --random --threads 80

