#!/bin/bash -e

#
# EarnstoneUtils: Earnstone Utilities.
# 
# Copyright 2010 Corey Hulen, Earnstone Corporation
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License. 
#
 
export DEBIAN_FRONTEND=noninteractive

echo "deb http://us.ec2.archive.ubuntu.com/ubuntu/ karmic multiverse" | sudo -E tee -a /etc/apt/sources.list
echo "deb-src http://us.ec2.archive.ubuntu.com/ubuntu/ karmic multiverse" | sudo -E tee -a /etc/apt/sources.list	
echo "deb http://us.ec2.archive.ubuntu.com/ubuntu/ karmic-updates multiverse" | sudo -E tee -a /etc/apt/sources.list
echo "deb-src http://us.ec2.archive.ubuntu.com/ubuntu/ karmic-updates multiverse" | sudo -E tee -a /etc/apt/sources.list
 
# run an update and upgarde
sudo -E apt-get update	-y	
sudo -E apt-get upgrade -y

# install java 6 runtime
echo "sun-java6-jdk shared/accepted-sun-dlj-v1-1 boolean true" | sudo -E debconf-set-selections	
sudo -E apt-get install -y sun-java6-jdk
echo "export JAVA_HOME=/usr/lib/jvm/java-6-sun" | sudo -E tee -a ~/.bashrc		

# Install munin node to monitor this instance
sudo -E apt-get install -y munin-node
# Replace the Munin cpu plugin with one that recognizes "steal" CPU cycles
sudo -E curl -o /usr/share/munin/plugins/cpu https://anvilon.s3.amazonaws.com/web/20081117-munin/cpu
sudo -E curl -o /usr/share/munin/plugins/plugin.sh https://anvilon.s3.amazonaws.com/web/20081117-munin/plugin.sh

#Install the casandra munin plugins for monitoring a cassandra server.
sudo -E apt-get install -y git-core
git clone http://github.com/jamesgolick/cassandra-munin-plugins.git
chmod u+x ~/cassandra-munin-plugins/jmx_
sudo -E ln -s ~/cassandra-munin-plugins/jmx_ /etc/munin/plugins/jvm_memory
sudo -E ln -s ~/cassandra-munin-plugins/jmx_ /etc/munin/plugins/ops_pending

# allow all machines to see the munin-node
echo cidr_allow 0.0.0.0/0 | sudo tee -a /etc/munin/munin-node.conf

sudo -E /etc/init.d/munin-node restart
	 
# intall monitor tools
sudo -E apt-get install -y sysstat

# download and untar cassandra in the users home directory
wget -q http://www.apache.org/dist/cassandra/0.6.2/apache-cassandra-0.6.2-bin.tar.gz
tar -zxf apache-cassandra-0.6.2-bin.tar.gz
echo "export CASSANDRA_HOME=~/earnstone/Software/apache-cassandra-0.6.2" | sudo -E tee -a ~/.bashrc
rm apache-cassandra-0.6.2-bin.tar.gz
source ~/.bashrc

#copy over the storage config if one was provided.
if [ -e ./storage-conf*.xml ]; then
    cp ./storage-conf*.xml ./apache-cassandra-0.6.2/conf/storage-conf.xml
fi

sudo -E apt-get install -y mdadm xfsprogs

sudo -E mkdir /var/lib/cassandra
sudo -E chown ubuntu /var/lib/cassandra
sudo -E mkdir /var/log/cassandra
sudo -E chown ubuntu /var/log/cassandra
mkdir /var/lib/cassandra/commitlog /var/lib/cassandra/data

# configure and mount the EBS drive if one was created
# for the commit log.
if [ -e /dev/sdf ]; then        
    sudo -E mkfs.xfs /dev/sdf
    echo "/dev/sdf /disk1 xfs noatime 0 0" | sudo -E tee -a /etc/fstab
    sudo -E mkdir -m 000 /disk1
    sudo -E mount /disk1
    sudo -E mkdir /disk1/cassandra
    sudo -E chown ubuntu /disk1/cassandra
    mkdir /disk1/cassandra/commitlog

    echo "/disk1/cassandra/commitlog /var/lib/cassandra/commitlog     none bind" | sudo -E tee -a /etc/fstab
    sudo -E mount /var/lib/cassandra/commitlog
fi

# If there is 2 or more drives then create them
# as a Raid 0 array
if [ -e /dev/sdh ] && [ -e /dev/sdi ]; then
   possibledrives=(sdh sdi sdj sdk sdl sdm sdn sdo sdp)
   acutaldrives="";
   drivecount=0;

   for posdrive in ${possibledrives[*]}
   do
      if [ -e /dev/$posdrive ]; then
         acutaldrives="$acutaldrives /dev/$posdrive";
         (( drivecount++ ));
      fi
   done
   
   sudo mdadm --create /dev/md0 --level 0 --chunk=256 --metadata=1.1 --raid-devices=$drivecount $acutaldrives
   echo DEVICE $acutaldrives | sudo tee /etc/mdadm/mdadm.conf
   sudo mdadm --detail --scan | sudo tee -a /etc/mdadm/mdadm.conf
   sudo mkfs.xfs /dev/md0
   echo "/dev/md0 /disk2 xfs noatime 0 0" | sudo tee -a /etc/fstab
   sudo mkdir /disk2
   sudo mount /disk2
   sudo blockdev --setra 65536 /dev/md0

   sudo -E mkdir /disk2/cassandra
   sudo -E chown ubuntu /disk2/cassandra
   mkdir /disk2/cassandra/data

   echo "/disk2/cassandra/data /var/lib/cassandra/data     none bind" | sudo -E tee -a /etc/fstab
   sudo -E mount /var/lib/cassandra/data   
fi

echo "WARN: cassandra was not started. You must upload your storage-conf.xml"
echo "      and start cassandra from CASSANDRA_HOME/bin"





