
DESCRIPTION README_client.txt
=========================================================================
This readme will walk you through the steps we used to create the
client machines for the stress tests.


First Client Test Machine
=========================================================================

Step 1: Create a small instance running cassandra

   user@localmachine:~$ ./setup_box.sh -p "/home/user/path/YourPemKeyFile.pem" cassandra-stress-client.sh

Step 2: Add the cassandra nodes to munin for monitoring

   ubuntu@domU-XX-XX-XX-XX-XX-c1:~$ sudo nano /etc/munin/munin.conf
   
   Add the following lines to the munin configuration file

    [Node1.Cassandra]
        address domU-XX-XX-XX-XX-XX-a1
        use_node_name yes
