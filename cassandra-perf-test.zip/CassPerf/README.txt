See each of the respective readme's for how to setup and stress test a paticular configuration.
