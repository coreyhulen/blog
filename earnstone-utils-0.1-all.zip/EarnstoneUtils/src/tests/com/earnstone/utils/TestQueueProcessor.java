package com.earnstone.utils;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.xerox.amazonws.sqs2.MessageQueue;
import com.xerox.amazonws.sqs2.Message;
import com.xerox.amazonws.sqs2.QueueService;
import com.xerox.amazonws.sqs2.SQSException;

public class TestQueueProcessor {   
   
   private static final Log log = LogFactory.getLog(TestQueueProcessor.class);
   
   static QueueService service;
   
   @BeforeClass
   public static void setUp() throws IOException {
      
      Properties props = new Properties();
      props.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("amazon_keys.properties"));
      service = new QueueService(props.getProperty("amazon.accesskey"), props.getProperty("amazon.secretkey"));
      
      // service = new QueueService("enter you access key here", "enter you secret key here");
   }
   
   @AfterClass
   public static void tearDown() {
   }
   
   @Test
   public void basicTest() throws SQSException {
      
      MessageQueue queue = service.getOrCreateMessageQueue("TestQueueProcessor_basicTest");
      
      long testRun = System.currentTimeMillis();      
      for (int i = 0; i < 10; i++) {
         queue.sendMessage("payload " + i + " (" + testRun + ")");
      }
      
      QueueProcessor processor = new QueueProcessor(queue, new MessageHandler() {
         
         @Override
         public void process(MessageQueue queue, Message message) {            
            try {               
               String body = message.getMessageBody();
               log.debug("basicTest message " + body + " Thread id " + Thread.currentThread().getId() + " processed");
               queue.deleteMessage(message);
            }
            catch (SQSException e) {
               Assert.fail();
            }
         }
      });
      
      processor.start();
            
      while (processor.getCompletedTaskCount() < 10) {
         try {
            Thread.sleep(200);
         }
         catch (InterruptedException e) {
            e.printStackTrace();
         }
      }
      
      processor.shutdown();  
      processor.waitForShutdown();
      
      queue.deleteQueue();
   }  
   
   @Test
   public void testReuse() throws SQSException {
      
      MessageQueue queue = service.getOrCreateMessageQueue("TestQueueProcessor_testReuse1");
      
      long testRun = System.currentTimeMillis();      
      for (int i = 0; i < 10; i++) {
         queue.sendMessage("payload " + i + " (" + testRun + ")");
      }
      
      QueueProcessor processor = new QueueProcessor(queue, new MessageHandler() {
         
         @Override
         public void process(MessageQueue queue, Message message) {            
            try {               
               String body = message.getMessageBody();
               log.debug("testReuse message " + body + " Thread id " + Thread.currentThread().getId() + " processed");
               queue.deleteMessage(message);
            }
            catch (SQSException e) {
               Assert.fail();
            }
         }
      });
      
      processor.start();
            
      while (processor.getCompletedTaskCount() < 10) {
         try {
            Thread.sleep(200);
         }
         catch (InterruptedException e) {
            e.printStackTrace();
         }
      }
      
      processor.shutdown();  
      processor.waitForShutdown();
      
      for (int i = 10; i < 20; i++) {
         queue.sendMessage("payload " + i + " (" + testRun + ")");
      }
      
      processor.start();
      
      while (processor.getCompletedTaskCount() < 20) {
         try {
            Thread.sleep(200);
         }
         catch (InterruptedException e) {
            e.printStackTrace();
         }
      }
      
      processor.shutdown();  
      processor.waitForShutdown();
      
      queue.deleteQueue();
   }  
   
   @Test
   public void simpleLoadTest() throws SQSException {
      
      MessageQueue queue = service.getOrCreateMessageQueue("TestQueueProcessor_loadTest");
      
      long testRun = System.currentTimeMillis();      
      for (int i = 0; i < 200; i++) {
         queue.sendMessage("payload " + i + " (" + testRun + ")");
      }
      
      QueueProcessor processor = new QueueProcessor(queue, new MessageHandler() {
         
         AtomicInteger count = new AtomicInteger();
         
         @Override
         public void process(MessageQueue queue, Message message) {            
            try {                              
               String body = message.getMessageBody();
               log.debug("simpleLoadTest message " + body + " Thread id " + Thread.currentThread().getId() + " processed " + count.incrementAndGet());
               Thread.sleep(2000);
               queue.deleteMessage(message);
            }
            catch (Exception e) {
               Assert.fail();
            }
         }
      });
      
      processor.setMaximumPoolSize(5);
      
      processor.start();
            
      while (processor.getCompletedTaskCount() < 200) {
         try {
            Thread.sleep(1000);
         }
         catch (InterruptedException e) {
            e.printStackTrace();
         }
      }
      
      processor.shutdown();   
      processor.waitForShutdown();
      
      queue.deleteQueue();
   } 
}
