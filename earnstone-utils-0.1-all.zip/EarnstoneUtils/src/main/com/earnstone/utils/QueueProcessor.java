/*
 * EarnstoneUtils: Earnstone Utilities.
 * 
 * Copyright 2010 Corey Hulen, Earnstone Corporation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package com.earnstone.utils;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.xerox.amazonws.sqs2.Message;
import com.xerox.amazonws.sqs2.MessageQueue;
import com.xerox.amazonws.sqs2.SQSException;

public class QueueProcessor implements Runnable {

   protected static class MessageHandlerRunner implements Runnable {
      
      MessageQueue messageQueue;
      Message message;
      MessageHandler handler;
      AtomicInteger count;

      public MessageHandlerRunner(MessageQueue messageQueue, Message message, MessageHandler handler, AtomicInteger count) {
         this.messageQueue = messageQueue;
         this.message = message;
         this.handler = handler;
         this.count = count;
      }

      @Override
      public void run() {
         handler.process(messageQueue, message);
         count.incrementAndGet();
      }
   }

   private static final Log log = LogFactory.getLog(QueueProcessor.class);
   
   private AtomicInteger count = new AtomicInteger();
   private AtomicBoolean shutdown = new AtomicBoolean(false);
   private AtomicBoolean sleeping = new AtomicBoolean(false);

   protected MessageQueue queue;
   protected MessageHandler handler;
   protected ThreadPoolExecutor pool;
   protected Thread mainThread;

   protected int corePoolSize = 1;
   private int maximumPoolSize = 10;
   private int queueSize = maximumPoolSize * 4;
   private int threadkeepAliveTimeInSec = 15 * 60;
   private int awaitTerminationInSec = 2 * 60;
   private int poolingThreadDelayInSec = 30;

   public QueueProcessor() {      
   }

   public QueueProcessor(MessageQueue queue, MessageHandler handler) {      
      this.queue = queue;
      this.handler = handler;
   }

   @Override
   public void run() {
      
      log.info("Main thread starting with id=" + Thread.currentThread().getId());

      shutdown.set(false);

      BlockingQueue<Runnable> runQueue = new ArrayBlockingQueue<Runnable>(queueSize);
      pool = new ThreadPoolExecutor(corePoolSize, getMaximumPoolSize(), getThreadkeepAliveTimeInSec(), TimeUnit.SECONDS, runQueue, new ThreadPoolExecutor.CallerRunsPolicy());

      int agingThreadDelayInMillis = 2000;

      while (!shutdown.get()) {

         try {
            Message message = queue.receiveMessage();

            if (message == null) {
               try {
                  sleeping.set(true);
                  Thread.sleep(agingThreadDelayInMillis);
                  sleeping.set(false);                  
               }
               catch (InterruptedException e) {
               }
               
               agingThreadDelayInMillis = agingThreadDelayInMillis * 2;
               if (agingThreadDelayInMillis > poolingThreadDelayInSec)
                  agingThreadDelayInMillis = poolingThreadDelayInSec;
            }
            else {               
               pool.execute(new MessageHandlerRunner(queue, message, handler, count));               
               agingThreadDelayInMillis = 2000;
            }
         }
         catch (SQSException e) {
            log.error(e);
         }
      }

      log.debug("Main thread loop ended for id=" + Thread.currentThread().getId());
      log.debug("Attempting to shutdown thread pool for main thread id=" + Thread.currentThread().getId());
      pool.shutdown();

      try {
         if (!pool.awaitTermination(getAwaitTerminationInSec(), TimeUnit.SECONDS)) {
            pool.shutdownNow();
            pool.awaitTermination(getAwaitTerminationInSec(), TimeUnit.SECONDS);
         }
      }
      catch (InterruptedException e) {
         pool.shutdownNow();
         Thread.currentThread().interrupt();
         log.error(e);
      }
      
      log.debug("Shutdown complete for main thread id=" + Thread.currentThread().getId());

      pool = null;
      mainThread = null;
   }
   
   public void start() {
      mainThread = new Thread(this);
      mainThread.setDaemon(true);
      mainThread.start();
   }

   public void shutdown() {
      
      if (mainThread == null)
         log.info("shutdown command recieved, but already shutdown.");
      else
         log.info("shutdown command recieved for main thread with id=" + mainThread.getId());
      
      shutdown.set(true);

      if (sleeping.get() && mainThread != null)
         mainThread.interrupt();
   }
   
   public void waitForShutdown() {
      try {
         if (mainThread != null)
            mainThread.join();
      }
      catch (InterruptedException e) {         
      }
   }
   
   public boolean isShutdown() {
      return mainThread == null && pool == null;
   }

   public void setQueue(MessageQueue queue) {
      this.queue = queue;
   }

   public MessageQueue getQueue() {
      return queue;
   }

   public void setMessageHandler(MessageHandler handler) {
      this.handler = handler;
   }

   public MessageHandler getMessageHandler() {
      return handler;
   }

   public void setMaximumPoolSize(int maximumPoolSize) {
      this.queueSize = maximumPoolSize * 4;
      this.maximumPoolSize = maximumPoolSize;
   }

   public int getMaximumPoolSize() {
      return maximumPoolSize;
   }

   public void setThreadkeepAliveTimeInSec(int threadkeepAliveTimeInSec) {
      this.threadkeepAliveTimeInSec = threadkeepAliveTimeInSec;
   }

   public int getThreadkeepAliveTimeInSec() {
      return threadkeepAliveTimeInSec;
   }

   public void setAwaitTerminationInSec(int awaitTerminationInSec) {
      this.awaitTerminationInSec = awaitTerminationInSec;
   }

   public int getAwaitTerminationInSec() {
      return awaitTerminationInSec;
   }

   public void setPoolingThreadDelayInSec(int poolingThreadDelayInSec) {
      this.poolingThreadDelayInSec = poolingThreadDelayInSec;
   }

   public int getPoolingThreadDelayInSec() {
      return poolingThreadDelayInSec;
   }

   public int getActiveProcesses() {
      if (pool != null)
         return pool.getActiveCount();
      else
         return 0;
   }

   public long getCompletedTaskCount() {
      return count.get();
   }

   public long getItemsAwaitingProcessing() {
      if (pool != null)
         return pool.getQueue().size();
      else
         return 0;
   }
}
