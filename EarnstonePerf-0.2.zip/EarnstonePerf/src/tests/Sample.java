
import com.earnstone.perf.PerfAvg;
import com.earnstone.perf.PerfAvgCallsPerSec;
import com.earnstone.perf.PerfAvgTime;
import com.earnstone.perf.PerfIncrement;
import com.earnstone.perf.PerfLastAccessTime;
import com.earnstone.perf.PerfPercent;
import com.earnstone.perf.PerfRegistry;
import com.earnstone.perf.PerfAvgCallsPerSec.PerTime;

public class Sample {

   public static void main(String[] args) throws Exception {

      PerfIncrement countSimple = new PerfIncrement();
      countSimple.setCategory("My Category");
      countSimple.setName("Simple Count");
      PerfRegistry.register(countSimple);
      countSimple.increment();
      countSimple.incrementBy(12345);
      countSimple.decrement();
      System.out.println(countSimple.getRawDoubleValue());
      System.out.println(countSimple.getDisplayValue());

      PerfIncrement countPertty = new PerfIncrement();
      countPertty.setCategory("My Category");
      countPertty.setName("Pertty Count");
      countPertty.setFormatter("#,### total count");
      PerfRegistry.register(countPertty);
      countPertty.incrementBy(123456789);
      System.out.println(countPertty.getRawDoubleValue());
      System.out.println(countPertty.getDisplayValue());

      PerfAvg avgSimple = new PerfAvg();
      avgSimple.setCategory("My Category");
      avgSimple.setName("Simple Average");
      PerfRegistry.register(avgSimple);
      avgSimple.addValue(1);
      avgSimple.addValue(2);
      avgSimple.addValue(7);
      System.out.println(avgSimple.getRawDoubleValue());
      System.out.println(avgSimple.getDisplayValue());

      PerfAvgTime avgTime = new PerfAvgTime();
      avgTime.setCategory("My Category");
      avgTime.setName("Average Time");
      PerfRegistry.register(avgTime);

      for (int i = 0; i < 2; i++) {

         long startTime = System.currentTimeMillis();
         Thread.sleep(1001);
         avgTime.addTime(startTime, System.currentTimeMillis());
      }

      System.out.println(avgTime.getRawDoubleValue());
      System.out.println(avgTime.getDisplayValue());

      PerfLastAccessTime upTime = new PerfLastAccessTime();
      upTime.setCategory("My Category");
      upTime.setName("Up Time");
      PerfRegistry.register(upTime);
      upTime.updateLastAccess();
      Thread.sleep(1001);
      System.out.println(upTime.getRawDoubleValue());
      System.out.println(upTime.getDisplayValue());

      PerfPercent percent = new PerfPercent();
      percent.setCategory("My Category 2");
      percent.setName("Percent");
      PerfRegistry.register(percent);
      percent.increment();
      percent.incrementBase();
      percent.incrementBase();
      percent.incrementBase();
      System.out.println(percent.getRawDoubleValue());
      System.out.println(percent.getDisplayValue());

      PerfPercent percentInverse = new PerfPercent();
      percentInverse.setCategory("My Category 2");
      percentInverse.setName("Percent Inverted");
      percentInverse.setInverse(true);
      PerfRegistry.register(percentInverse);
      percentInverse.increment();
      percentInverse.incrementBase();
      percentInverse.incrementBase();
      percentInverse.incrementBase();
      System.out.println(percentInverse.getRawDoubleValue());
      System.out.println(percentInverse.getDisplayValue());

      PerfAvgCallsPerSec avgCalls = new PerfAvgCallsPerSec();
      avgCalls.setCategory("My Category 2");
      avgCalls.setName("Average Calls");
      PerfRegistry.register(avgCalls);

      for (int i = 0; i < 20; i++) {
         avgCalls.incrementCall();
         Thread.sleep(10);
      }

      System.out.println(avgCalls.getRawDoubleValue());
      System.out.println(avgCalls.getDisplayValue());

      avgCalls.setPerTime(PerTime.Min);
      System.out.println(avgCalls.getDisplayValue());

      System.out.println("-------------------------------------------");
      System.out.println(PerfRegistry.printPerfs(PerfRegistry.listAllCounters()));

      System.out.println("-------------------------------------------");
      PerfRegistry.registerJmxBeans(9005, 9006);

      System.out.println("System waiting (Conect with jconsole to see perf counters)");
      System.out.println("Hit any key to continue...");
      System.in.read();
   }
}
