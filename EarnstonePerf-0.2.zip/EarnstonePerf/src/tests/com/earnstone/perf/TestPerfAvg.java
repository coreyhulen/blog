package com.earnstone.perf;

import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;

public class TestPerfAvg {   

   @Test
   public void getSetTest() {
      PerfAvg avg = new PerfAvg();

      avg.setCategory("category");
      Assert.assertEquals("category", avg.getCategory());

      avg.setCategory("category2");
      Assert.assertEquals("category", avg.getCategory());

      avg.setName("name");
      Assert.assertEquals("name", avg.getName());

      avg.setName("name2");
      Assert.assertEquals("name", avg.getName());

      avg.setDescription("description");
      Assert.assertEquals("description", avg.getDescription());

      avg.setDescription(null);
      Assert.assertEquals("", avg.getDescription());

      avg.setFormatter("# test");
      avg.setFormatter(null);
      
      avg.setSampleSize(256);
      Assert.assertEquals(256, avg.getSampleSize());
   }

   @Test
   public void incrementDecrementTest() {
      PerfAvg avg = new PerfAvg();
      avg.setSampleSize(4);
      
      Assert.assertEquals(0, avg.getRawSample().length);      
      
      avg.addValue(10);
      Assert.assertEquals(10, avg.getRawDoubleValue(), 0);
      Assert.assertEquals(1, avg.getRawSample().length);
      Assert.assertEquals(10, avg.getRawSample()[0]);
      
      avg.addValue(10);
      Assert.assertEquals(10, avg.getRawDoubleValue(), 0);
      Assert.assertEquals(2, avg.getRawSample().length);
      Assert.assertEquals(10, avg.getRawSample()[1]);
      
      avg.addValue(10);
      Assert.assertEquals(10, avg.getRawDoubleValue(), 0);
      Assert.assertEquals(3, avg.getRawSample().length);
      Assert.assertEquals(10, avg.getRawSample()[2]);
      
      avg.addValue(10);
      Assert.assertEquals(10, avg.getRawDoubleValue(), 0);
      Assert.assertEquals(4, avg.getRawSample().length);
      Assert.assertEquals(10, avg.getRawSample()[3]);
      
      avg.addValue(5);
      Assert.assertEquals(8.75, avg.getRawDoubleValue(), 0);      
      Assert.assertEquals(4, avg.getRawSample().length);
      Assert.assertEquals(5, avg.getRawSample()[0]);
   }

   @Test
   public void displayValueTest() {
      PerfAvg avg = new PerfAvg();
      avg.addValue(10);
      avg.addValue(10);
      avg.addValue(10);
      avg.addValue(5);      
      
      Assert.assertEquals("8.75", avg.getDisplayValue());

      avg.setFormatter("#.000 test");
      Assert.assertEquals("8.750 test", avg.getDisplayValue());

      avg.setFormatter(null);
      Assert.assertEquals("8.75", avg.getDisplayValue());
   }
   
   @Category(ILoadTests.class)
   @Test
   public void simpleSpeedTest() {
      System.out.println("begin TestPerfCounterAvg.simpleSpeedTest");
      
      PerfAvg avg = new PerfAvg();

      long finish = 0;
      long start = 0;
      
      long control = 0;
      
      start = System.currentTimeMillis();      
      for (int i = 0; i < 10000000; i++) {         
         control = control + 1;
      }      
      finish = System.currentTimeMillis();
      
      System.out.println("Control (to 1 billion) " + (finish - start) + " ms");
      
      start = System.currentTimeMillis();      
      for (int i = 0; i < 10000000; i++) {
         avg.addValue(i);
      }      
      finish = System.currentTimeMillis();
      
      System.out.println("Counter (to 1 billion) " + (finish - start) + " ms");
      System.out.println("end TestPerfCounterAvg.simpleSpeedTest");
   }

   @Category(ILoadTests.class)
   @Test
   public void simpleLoadTest() {

      final PerfAvg avg = new PerfAvg();
      avg.setCategory("Load Test");
      avg.setName("Load Avg");

      LoadTest loadTest1 = new LoadTest(10, new Runnable() {
         @Override
         public void run() {
            int i = 0;
            while (true) {
               avg.addValue(i++);               
            }
         }
      });

      LoadTest loadTest2 = new LoadTest(4, new Runnable() {
         @Override
         public void run() {
            while (true) {
               avg.getRawDoubleValue();
               avg.getDisplayValue();
            }
         }
      });
      
      loadTest1.begin();
      loadTest2.begin();

      try {
         Thread.sleep(20000);
      }
      catch (InterruptedException e) {         
      }
      
      loadTest1.end();
      loadTest2.end();
      
      Assert.assertFalse(loadTest1.getErrors(), loadTest1.hadError());
      Assert.assertFalse(loadTest2.getErrors(), loadTest2.hadError());
      
      System.out.println(avg.getDisplayValue());
   }
}
