package com.earnstone.perf;

import org.junit.Assert;
import org.junit.Test;

public class TestPerfLastAccessTime {   
  
   @Test
   public void incrementDecrementTest() throws InterruptedException {
      PerfLastAccessTime time = new PerfLastAccessTime();
      time.updateLastAccess();
      Thread.sleep(210);
      Assert.assertTrue(200.0 <= time.getRawLongValue());
   }

   @Test
   public void displayValueTest() {
      PerfLastAccessTime time = new PerfLastAccessTime();
      
      Assert.assertEquals(PerfUtils.NA, time.getDisplayValue());
      
      time.updateLastAccess();
      time.getDisplayValue();
      
      time.set(0);
      time.getDisplayValue();      
   }  
}
