package com.earnstone.perf;

public interface ILoadTests {

}
