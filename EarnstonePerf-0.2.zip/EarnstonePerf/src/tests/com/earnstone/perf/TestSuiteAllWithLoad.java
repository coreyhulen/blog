package com.earnstone.perf;

import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Categories.class)
@SuiteClasses( { 
   TestPerfIncrement.class, 
   TestPerfAvg.class, 
   TestPerfAvgTime.class, 
   TestPerfLastAccessTime.class, 
   TestPerfPercent.class,
   TestPerfAvgCallsPerSec.class
})
public class TestSuiteAllWithLoad {

}
