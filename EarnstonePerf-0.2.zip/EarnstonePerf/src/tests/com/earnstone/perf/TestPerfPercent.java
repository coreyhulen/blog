package com.earnstone.perf;

import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;

public class TestPerfPercent {   

   @Test
   public void getSetTest() {
      PerfPercent percent = new PerfPercent();

      percent.setFormatter("#.00% test");
      percent.setFormatter(null);
      
      percent.setInverse(true);
      Assert.assertEquals(true, percent.getInverse());
   }

   @Test
   public void incrementDecrementTest() {
      PerfPercent percent = new PerfPercent();
      
      Assert.assertEquals(0, percent.getRawDoubleValue(), 0);

      percent.incrementBase();
      Assert.assertEquals(1, percent.getRawSample()[1], 0);

      percent.incrementBase();
      Assert.assertEquals(2, percent.getRawSample()[1], 0);

      percent.incrementBaseBy(3);
      Assert.assertEquals(5, percent.getRawSample()[1], 0);

      percent.decrementBase();
      Assert.assertEquals(4, percent.getRawSample()[1], 0);

      percent.decrementBase();
      Assert.assertEquals(3, percent.getRawSample()[1], 0);

      percent.decrementBaseBy(2);
      Assert.assertEquals(1, percent.getRawSample()[1], 0);

      Assert.assertEquals(2, percent.getRawSample().length);
      Assert.assertEquals(1, percent.getRawSample()[1]);
      
      percent.setBase(100);
      Assert.assertEquals(100, percent.getRawSample()[1], 0);      
      
      percent.set(3);
      percent.setBase(4);
      Assert.assertEquals(.75, percent.getRawDoubleValue(), 0);
      
      percent.setInverse(true);
      Assert.assertEquals(.25, percent.getRawDoubleValue(), 0);
   }

   @Test
   public void displayValueTest() {
      PerfPercent percent = new PerfPercent();

      percent.set(3);
      percent.setBase(4);
      Assert.assertEquals("75.0%", percent.getDisplayValue());

      percent.setFormatter("#% test");
      Assert.assertEquals("75% test", percent.getDisplayValue());

      percent.setBase(7);
      percent.setFormatter(null);
      Assert.assertEquals("42.9%", percent.getDisplayValue());      
   }
   
   @Category(ILoadTests.class)
   @Test
   public void simpleSpeedTest() {
      
      System.out.println("begin TestPerfCounterPercent.simpleSpeedTest");
      
      PerfPercent percent = new PerfPercent();

      long finish = 0;
      long start = 0;
      
      long control = 0;
      
      start = System.currentTimeMillis();      
      for (int i = 0; i < 10000000; i++) {         
         control = control + 1;
      }      
      finish = System.currentTimeMillis();
      
      System.out.println("Control (to 1 billion) " + (finish - start) + " ms");
      
      start = System.currentTimeMillis();      
      for (int i = 0; i < 10000000; i++) {
         percent.increment();
         percent.incrementBase();         
      }      
      finish = System.currentTimeMillis();
      
      System.out.println("Counter (to 1 billion) " + (finish - start) + " ms");
      System.out.println("end TestPerfCounterPercent.simpleSpeedTest");
   }

   @Category(ILoadTests.class)
   @Test
   public void simpleLoadTest() {

      final PerfPercent percent = new PerfPercent();
      percent.setCategory("Load Test");
      percent.setName("Load Count");

      LoadTest loadTest1 = new LoadTest(10, new Runnable() {
         @Override
         public void run() {
            while (true) {
               percent.increment(); 
               percent.incrementBaseBy(2);               
            }
         }
      });

      LoadTest loadTest2 = new LoadTest(4, new Runnable() {
         @Override
         public void run() {
            while (true) {
               percent.getRawDoubleValue();
               percent.getDisplayValue();
            }
         }
      });
      
      loadTest1.begin();
      loadTest2.begin();

      try {
         Thread.sleep(20000);
      }
      catch (InterruptedException e) {         
      }
      
      loadTest1.end();
      loadTest2.end();
      
      Assert.assertFalse(loadTest1.getErrors(), loadTest1.hadError());
      Assert.assertFalse(loadTest2.getErrors(), loadTest2.hadError());
      
      System.out.println(percent.getDisplayValue());
   }
}
