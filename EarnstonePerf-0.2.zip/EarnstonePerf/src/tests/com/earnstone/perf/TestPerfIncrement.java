package com.earnstone.perf;

import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;

public class TestPerfIncrement {   

   @Test
   public void getSetTest() {
      PerfIncrement count = new PerfIncrement();

      count.setCategory("category");
      Assert.assertEquals("category", count.getCategory());      

      count.setName("name");
      Assert.assertEquals("name", count.getName());      

      count.setDescription("description");
      Assert.assertEquals("description", count.getDescription());      

      count.setFormatter("# test");
      count.setFormatter(null);
   }

   @Test
   public void incrementDecrementTest() {
      PerfIncrement count = new PerfIncrement();

      count.increment();
      Assert.assertEquals(1, count.getRawLongValue());

      count.increment();
      Assert.assertEquals(2, count.getRawLongValue());

      count.incrementBy(3);
      Assert.assertEquals(5, count.getRawLongValue());

      count.decrement();
      Assert.assertEquals(4, count.getRawLongValue());

      count.decrement();
      Assert.assertEquals(3, count.getRawLongValue());

      count.decrementBy(2);
      Assert.assertEquals(1, count.getRawLongValue());

      Assert.assertEquals(1, count.getRawSample().length);
      Assert.assertEquals(1, count.getRawSample()[0]);
      
      count.set(100);
      Assert.assertEquals(100, count.getRawLongValue());      
   }

   @Test
   public void displayValueTest() {
      PerfIncrement count = new PerfIncrement();

      count.incrementBy(12345);
      Assert.assertEquals("12345", count.getDisplayValue());

      count.setFormatter("#,### test");
      Assert.assertEquals("12,345 test", count.getDisplayValue());

      count.setFormatter(null);
      Assert.assertEquals("12345", count.getDisplayValue());
   }
   
   @Category(ILoadTests.class)
   @Test
   public void simpleSpeedTest() {
      
      System.out.println("begin TestPerfCounterCount.simpleSpeedTest");
      
      PerfIncrement count = new PerfIncrement();

      long finish = 0;
      long start = 0;
      
      long control = 0;
      
      start = System.currentTimeMillis();      
      for (int i = 0; i < 10000000; i++) {         
         control = control + 1;
      }      
      finish = System.currentTimeMillis();
      
      System.out.println("Control (to 1 billion) " + (finish - start) + " ms");
      
      start = System.currentTimeMillis();      
      for (int i = 0; i < 10000000; i++) {
         count.increment();
      }      
      finish = System.currentTimeMillis();
      
      System.out.println("Counter (to 1 billion) " + (finish - start) + " ms");
      System.out.println("end TestPerfCounterCount.simpleSpeedTest");
   }

   @Category(ILoadTests.class)
   @Test
   public void simpleLoadTest() {

      final PerfIncrement count = new PerfIncrement();
      count.setCategory("Load Test");
      count.setName("Load Count");

      LoadTest loadTest1 = new LoadTest(10, new Runnable() {
         @Override
         public void run() {
            while (true) {
               count.increment();               
            }
         }
      });

      LoadTest loadTest2 = new LoadTest(4, new Runnable() {
         @Override
         public void run() {
            while (true) {
               count.getRawLongValue();
               count.getDisplayValue();
            }
         }
      });
      
      loadTest1.begin();
      loadTest2.begin();

      try {
         Thread.sleep(20000);
      }
      catch (InterruptedException e) {         
      }
      
      loadTest1.end();
      loadTest2.end();
      
      Assert.assertFalse(loadTest1.getErrors(), loadTest1.hadError());
      Assert.assertFalse(loadTest2.getErrors(), loadTest2.hadError());
      
      System.out.println(count.getDisplayValue());
   }
}
