package com.earnstone.perf;

import org.junit.Assert;
import org.junit.Test;

public class TestPerfAvgTime {   

   @Test
   public void getSetTest() {
      PerfAvgTime avg = new PerfAvgTime();

      avg.setSampleSize(256);
      Assert.assertEquals(256, avg.getSampleSize());
   }

   @Test
   public void incrementDecrementTest() {
      PerfAvgTime avg = new PerfAvgTime();
      avg.setSampleSize(4);
                  
      Assert.assertEquals(0, avg.getRawSample().length);      
      
      avg.addTime(1000, 1900);
      Assert.assertEquals(900, avg.getRawDoubleValue(), 0);
      Assert.assertEquals(1, avg.getRawSample().length);
      Assert.assertEquals(900, avg.getRawSample()[0]);
   }

   @Test
   public void displayValueTest() {
      PerfAvgTime avg = new PerfAvgTime();
      
      Assert.assertEquals("0 s", avg.getDisplayValue());
      
      avg.setSampleSize(1);
      avg.addTime(0, 1000);
      Assert.assertEquals("1 s", avg.getDisplayValue());
            
      avg.addTime(0, 1000 * 60);
      Assert.assertEquals("1 m 0 s", avg.getDisplayValue());
            
      avg.addTime(0, 1000 * 60 * 60);
      Assert.assertEquals("1 hrs 0 m 0 s", avg.getDisplayValue());
      
      avg.addTime(0, 1000 * 60 * 60 * 24);
      Assert.assertEquals("1 days 0 hrs 0 m 0 s", avg.getDisplayValue());
      
      avg.addTime(0, 1000 * 60 * 60 * 24 * 4 + 1000 * 60 * 60 * 3 + 1000 * 60 * 40 + 1000 * 10);
      Assert.assertEquals("4 days 3 hrs 40 m 10 s", avg.getDisplayValue());
   }  
}
