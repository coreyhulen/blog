package com.earnstone.perf;

import java.util.ArrayList;

public class LoadTest {
      
   ArrayList<Thread> threads = new ArrayList<Thread>();
   ThreadGroup group;
   String firstError;
   String lastError;   
   
   public LoadTest(int numberOfThreads, Runnable testRun) {           
            
      group = new ThreadGroup(testRun.getClass().toString()) {
         
         @Override 
         public void uncaughtException(Thread t, Throwable e) {
            synchronized (LoadTest.class) {
               if (!(e instanceof ThreadDeath)) {
                  e.fillInStackTrace();
                  e.printStackTrace();
                  
                  if (firstError == null)
                     firstError = e.toString();               
                  else
                     lastError = e.toString();
               }
            }
         }
      };
      
      group.setDaemon(true);
            
      for (int i = 0; i < numberOfThreads; i++) {
         Thread thread = new Thread(group, testRun);         
         threads.add(thread);
      }       
   }         
   
   public boolean hadError() {
      return firstError != null;
   }
   
   public String getErrors() {
      String message = "";
      
      if (firstError != null)      
         message = "First Error: " + firstError;
      
      if (lastError != null)      
         message += " Last Error: " + lastError;
      
      return message;
   }
   
   public void begin() {      
      for (Thread thread : threads) {
         thread.start();
      }
   }
   
   @SuppressWarnings("deprecation")
   public void end() {      
      for (Thread thread : threads) {
         thread.stop();
      }      
   }   
}
