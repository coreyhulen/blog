/*
 * EarnstonePerf: Java Simple Performance Counter toolkit.
 * 
 * Copyright 2010 Corey Hulen, Earnstone Corporation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package com.earnstone.perf;

import java.util.concurrent.atomic.AtomicLong;

/**
 * A performance counter that counts. Use simple operations to increment and
 * decrement the raw count value. This class is considered thread safe.
 * 
 * @author Corey Hulen
 * 
 */
public class PerfIncrement extends PerfCounter {

   protected AtomicLong count = new AtomicLong();

   /**
    * The default constructor.
    */
   public PerfIncrement() {
   }

   /**
    * The display value of raw count as formatted by the supplied format string.
    */
   @Override
   public String getDisplayValue() {

      // Java formatters are not considered thread-safe
      // therefore we must synchronize access
      synchronized (formatter) {
         return formatter.format(count.get());
      }
   }

   /**
    * A size 1 array containing the raw count.
    */
   @Override
   public long[] getRawSample() {
      long[] raw = new long[1];
      raw[0] = count.get();
      return raw;
   }

   /**
    * The raw count value.
    */
   @Override
   public long getRawLongValue() {
      return count.get();
   }

   /**
    * The raw count value. Some precision may be lost. Use {#link
    * getRawValue2()} instead.
    */
   @Override
   public double getRawDoubleValue() {
      return count.get();
   }

   /**
    * Increments the count by 1.
    * 
    * @return The newly incremented count.
    */
   public long increment() {
      return count.incrementAndGet();
   }

   /**
    * Decrements the count by 1.
    * 
    * @return The newly decremented count.
    */
   public long decrement() {
      return count.decrementAndGet();
   }

   /**
    * Increments the count by the supplied value.
    * 
    * @param add
    *           The value to increment by.
    * @return The newly incremented count value.
    */
   public long incrementBy(long add) {
      return count.addAndGet(add);
   }

   /**
    * Decrements the count by the supplied value.
    * 
    * @param sub
    *           The value to decrement by (Should be positive).
    * @return The newly decremented count value.
    */
   public long decrementBy(long sub) {
      return count.addAndGet(-sub);
   }

   /**
    * Sets the value of count to the current value.
    * 
    * @param value
    *           The value to set.
    */
   public void set(long value) {
      count.set(value);
   }

   /**
    * {#link getRawSample} is preferred. This is only a copy of the long[] data.
    */
   @Override
   public double[] getRawDoubleSample() {
      return convertRawSample(getRawSample());
   }

}
