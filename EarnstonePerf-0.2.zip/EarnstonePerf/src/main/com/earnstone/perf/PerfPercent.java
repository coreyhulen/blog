/*
 * EarnstonePerf: Java Simple Performance Counter toolkit.
 * 
 * Copyright 2010 Corey Hulen, Earnstone Corporation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package com.earnstone.perf;

import java.text.DecimalFormat;
import java.util.concurrent.atomic.AtomicLong;

/**
 * A performance counter that calculates percent. Use simple operations to
 * increment and decrement the raw numerator and denominator values. This class
 * is considered thread safe. Great for hit cache performance counters. This
 * class is considered thread-safe.
 * 
 * @author Corey Hulen
 * 
 */
public class PerfPercent extends PerfIncrement {

   protected AtomicLong base = new AtomicLong();
   protected boolean inverse;

   public static final String FORMAT_DEFAULT = "#0.0%";

   /**
    * The default constructor.
    */
   public PerfPercent() {
      setFormatter(FORMAT_DEFAULT);
   }

   /**
    * True if the percent value should be inverted. The default is false. So 25%
    * would become 75%.
    */
   public boolean getInverse() {
      return inverse;
   }

   /**
    * Set to true to invert the percent value.
    */
   public void setInverse(boolean inverse) {
      this.inverse = inverse;
   }

   /**
    * Sets the format string to use.
    * 
    * @param formatter
    *           A format string that is used to construct a DecimalFormat. If
    *           null is supplied then we will use the default format string.
    *           derived classes may override the default implementation.
    */
   @Override
   public synchronized void setFormatter(String formatter) {
      if (formatter == null)
         this.formatter = new DecimalFormat(FORMAT_DEFAULT);
      else
         this.formatter = new DecimalFormat(formatter);
   }

   /**
    * The display value of percent as formatted by the supplied format string.
    */
   @Override
   public String getDisplayValue() {

      // Java formatters are not considered thread-safe
      // there for we must synchronize access
      synchronized (formatter) {
         return formatter.format(getRawDoubleValue());
      }
   }

   /**
    * A size 2 array containing the raw numerator is in position 0 and
    * denominator is in position 1.
    */
   @Override
   public long[] getRawSample() {
      long[] raw = new long[2];
      raw[0] = count.get();
      raw[1] = base.get();
      return raw;
   }

   /**
    * The raw percent.
    */
   @Override
   public double getRawDoubleValue() {

      double tempBase = base.get();
      double tempCount = count.get();

      double percent = tempBase == 0 ? 0.0 : tempCount / tempBase;

      if (inverse)
         percent = 1 - percent;

      return percent;
   }

   /**
    * Increments the denominator by 1.
    * 
    * @return The newly incremented denominator.
    */
   public long incrementBase() {
      return base.incrementAndGet();
   }

   /**
    * Decrements the denominator by 1.
    * 
    * @return The newly decremented denominator.
    */
   public long decrementBase() {
      return base.decrementAndGet();
   }

   /**
    * Increments the denominator by the supplied value.
    * 
    * @param add
    *           The value to increment by.
    * @return The newly incremented denominator value.
    */
   public long incrementBaseBy(long add) {
      return base.addAndGet(add);
   }

   /**
    * Decrements the denominator by the supplied value.
    * 
    * @param sub
    *           The value to decrement by (Should be positive).
    * @return The newly decremented denominator value.
    */
   public long decrementBaseBy(long sub) {
      return base.addAndGet(-sub);
   }

   /**
    * Sets the value of the denominator to the current value.
    * 
    * @param value
    *           The value to set.
    */
   public void setBase(long value) {
      base.set(value);
   }
}
