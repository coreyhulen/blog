/*
 * EarnstonePerf: Java Simple Performance Counter toolkit.
 * 
 * Copyright 2010 Corey Hulen, Earnstone Corporation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package com.earnstone.perf;

/**
 * A performance counter for averaging over a time sample. The big difference
 * between this class and its base <code>PerfCounterAvg</code> are some
 * convenience methods to display the results as time. This will display time as
 * '12 days 12 hrs 22 m 14 s'. Avg time have a methods call. This class is
 * considered thread-safe.
 * 
 * @author Corey Hulen
 * 
 */
public class PerfAvgTime extends PerfAvg {

   /**
    * The default constructor.
    */
   public PerfAvgTime() {      
   }

   /**
    * The display value average as formatted by the internal formatter to
    * display time as '12 days 12 hrs 22 m 14 s'. If values are zero then they
    * drop out of the display as '22 m 14 s'
    */
   @Override
   public String getDisplayValue() {
      return PerfUtils.getTimeSince((long)getAvg());
   }

   /**
    * A convenience method for adding time to the underlying array. Internally
    * it calls <code>addValue</code> from the base class.
    * 
    * @param startTimeInMillis
    *           The start time in milliseconds usually from
    *           <code>System.currentTimeMillis()</code>
    * @param endTimeInMillis
    *           The end time in milliseconds usually from
    *           <code>System.currentTimeMillis()</code>
    */
   public void addTime(long startTimeInMillis, long endTimeInMillis) {
      addValue(endTimeInMillis - startTimeInMillis);
   }
}
