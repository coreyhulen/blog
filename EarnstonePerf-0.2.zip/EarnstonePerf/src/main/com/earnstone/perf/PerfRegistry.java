/*
 * EarnstonePerf: Java Simple Performance Counter toolkit.
 * 
 * Copyright 2010 Corey Hulen, Earnstone Corporation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package com.earnstone.perf;

import java.lang.management.ManagementFactory;
import java.rmi.registry.LocateRegistry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.remote.JMXConnectorServer;
import javax.management.remote.JMXConnectorServerFactory;
import javax.management.remote.JMXServiceURL;

/**
 * A central thread-safe repository for counters. Although it is not required to
 * register your performance counters in the registry it is recommended. Some
 * other features like exposing performance counters via JMX may depend on the
 * performance registry.
 * 
 * @author Corey Hulen
 * 
 */
public class PerfRegistry {

   private static ArrayList<PerfCounter> perfs;
   private static boolean registeredJmx = false;

   static {
      synchronized (PerfRegistry.class) {
         if (perfs == null)
            perfs = new ArrayList<PerfCounter>();
      }
   }

   /**
    * Registers a performance counter in the system. If a counter with the
    * supplied category and name already exist then it will be replaced. If
    * either category or name are null or the empty string then an
    * IllegalArgumentException exception is thrown.
    * 
    * @param perf
    *           The performance counter to register.
    */
   public static void register(PerfCounter perf) {

      if (perf.getCategory() == null || perf.getCategory().length() == 0)
         throw new IllegalArgumentException("The performance counter cannot have an empty category");

      if (perf.getName() == null || perf.getName().length() == 0)
         throw new IllegalArgumentException("The performance counter cannot have an empty name");

      synchronized (perfs) {

         for (int i = 0; i < perfs.size(); i++) {
            if (perfs.get(i).getCategory().equals(perf.getCategory()) && perfs.get(i).getName().equals(perf.getName())) {
               perfs.remove(i);
               break;
            }
         }

         perfs.add(perf);
         Collections.sort(perfs);
      }
   }

   /**
    * A list of all the categories from performance counters registered.
    */
   public static List<String> listCategories() {
      ArrayList<String> cats = new ArrayList<String>();

      synchronized (perfs) {

         String catPrev = null;

         for (PerfCounter perf : perfs) {
            if (!perf.getCategory().equals(catPrev)) {
               catPrev = perf.getCategory();
               cats.add(catPrev);
            }
         }
      }

      return cats;
   }

   /**
    * Returns a newly created list with all the performance counters.
    */
   public static List<PerfCounter> listAllCounters() {
      return listCounters(null);
   }

   /**
    * Returns a newly created list with the performance counters for the
    * supplied category.
    * 
    * @param category
    *           The category to search for.
    * @return A newly created list of the performance counters. Can be a size of
    *         zero.
    */
   public static List<PerfCounter> listCounters(String category) {
      ArrayList<PerfCounter> catPerfs = new ArrayList<PerfCounter>();

      synchronized (perfs) {
         for (PerfCounter perf : perfs) {
            if (category == null || perf.getCategory().equals(category)) {
               catPerfs.add(perf);
            }
         }
      }

      return catPerfs;
   }

   /**
    * Convenience methods to pretty print a performance counter list. Assumes it
    * will be called with the results from <code>listAllCounters</code> or
    * <code>listCounters</code>, which returns a copy and therefore doesn't need
    * any thread safety.
    * 
    * @param list
    *           The list to print
    * @return The printed list.
    */
   public static String printPerfs(List<PerfCounter> list) {

      if (list == null || list.size() == 0)
         return "";

      StringBuilder builder = new StringBuilder(1024);

      int maxLength = 0;
      for (PerfCounter base : list) {
         maxLength = Math.max(base.getName().length(), maxLength);
      }

      String lastCat = null;
      for (PerfCounter base : list) {
         if (!base.getCategory().equals(lastCat)) {
            builder.append(base.getCategory()).append('\n');
            lastCat = base.getCategory();
         }

         builder.append("    ").append(base.getName());

         for (int i = 0; i < (maxLength - base.getName().length()); i++) {
            builder.append(' ');
         }

         builder.append("  ").append(base.getDisplayValue()).append('\n');
      }

      return builder.toString();
   }

   /**
    * Find the performance counter in the registry.
    * 
    * @param category
    *           The category of the performance counter
    * @param name
    *           The name of the performance counter
    * @return The corresponding performance counter. May return null.
    */
   public static PerfCounter getCounter(String category, String name) {

      synchronized (perfs) {
         for (PerfCounter perf : perfs) {
            if ((category == null || perf.getCategory().equals(category)) && perf.getName().equals(name)) {
               return perf;
            }
         }
      }

      return null;
   }

   
   /**
    * Registers the performance counters to display as a JMX bean.
    * 
    * @param jmxServerPort  
    * The server port to use for the JMXServiceURL.
    * @param jmxRegistryPort
    * The registry port to use for the JMXServiceURL.
    * @return
    * True if the registration was successful false otherwise.
    */
   public static boolean registerJmxBeans(int jmxServerPort, int jmxRegistryPort) {

      try {

         if (!registeredJmx) {
            registeredJmx = true;
            LocateRegistry.createRegistry(jmxRegistryPort);
            HashMap<String, Object> env = new HashMap<String, Object>();
            MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
            JMXServiceURL url = new JMXServiceURL("service:jmx:rmi://127.0.0.1:" + jmxServerPort + "/jndi/rmi://127.0.0.1:" + jmxRegistryPort + "/jmxrmi");
            JMXConnectorServer cs = JMXConnectorServerFactory.newJMXConnectorServer(url, env, mbs);
            cs.start();

            for (String category : PerfRegistry.listCategories()) {
               JmxPerf perf = new JmxPerf(category);
               ObjectName objectName = new ObjectName(perf.getObjectTypeName());
               mbs.registerMBean(perf, objectName);
            }
         }
         
         return true;
      }
      catch (Exception ex) {
         return false;
      }
   }
}
