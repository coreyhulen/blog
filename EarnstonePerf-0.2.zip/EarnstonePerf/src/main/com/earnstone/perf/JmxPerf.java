/*
 * EarnstonePerf: Java Simple Performance Counter toolkit.
 * 
 * Copyright 2010 Corey Hulen, Earnstone Corporation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package com.earnstone.perf;

import java.util.List;

import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.AttributeNotFoundException;
import javax.management.DynamicMBean;
import javax.management.InvalidAttributeValueException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.ReflectionException;

public class JmxPerf implements DynamicMBean {

   private String category;

   public JmxPerf(String category) {
      this.category = category;
   }

   @Override
   public Object getAttribute(String name) throws AttributeNotFoundException, MBeanException, ReflectionException {

      PerfCounter counter = PerfRegistry.getCounter(category, name);

      if (counter != null)
         return counter.getDisplayValue();
      else
         return PerfUtils.NA;
   }

   @Override
   public AttributeList getAttributes(String[] names) {

      AttributeList list = new AttributeList();
      String value = null;

      for (String name : names) {

         PerfCounter counter = PerfRegistry.getCounter(category, name);

         if (counter != null)
            value = counter.getDisplayValue();
         else
            value = PerfUtils.NA;

         list.add(new Attribute(name, value));
      }

      return list;
   }

   @Override
   public MBeanInfo getMBeanInfo() {

      List<PerfCounter> counters = PerfRegistry.listCounters(category);
      MBeanAttributeInfo[] attrs = new MBeanAttributeInfo[counters.size()];

      for (int i = 0; i < counters.size(); i++) {
         attrs[i] = new MBeanAttributeInfo(counters.get(i).getName(), "java.lang.String", counters.get(i).getDescription(), true, false, false);
      }

      return new MBeanInfo("com.earnstone.perf." + RemoveSpecialCharacters(category), category, attrs, null, null, null);
   }

   @Override
   public Object invoke(String arg0, Object[] arg1, String[] arg2) throws MBeanException, ReflectionException {
      return null;
   }

   @Override
   public void setAttribute(Attribute attr) throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException {
   }

   @Override
   public AttributeList setAttributes(AttributeList attrList) {
      return new AttributeList();
   }
   
   public String getObjectTypeName() {
      return "com.earnstone.perf:type=" + RemoveSpecialCharacters(category);
   }   

   public static String RemoveSpecialCharacters(String str) {
      char[] buffer = new char[str.length()];
      int idx = 0;

      for (int i = 0; i < str.length(); i++) {
         char c = str.charAt(i);

         if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c == '.') || (c == '_')) {
            buffer[idx] = c;
            idx++;
         }
      }

      return new String(buffer, 0, idx);
   }
      
}
