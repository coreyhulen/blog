/*
 * EarnstonePerf: Java Simple Performance Counter toolkit.
 * 
 * Copyright 2010 Corey Hulen, Earnstone Corporation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package com.earnstone.perf;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLongArray;

/**
 * A performance counter for averaging over a sample. The focus is on
 * performance and being able to add raw values quickly to the sample. Under
 * high loads values can be missed. This class is considered thread safe.
 * 
 * @author Corey Hulen
 * 
 */
public class PerfAvg extends PerfCounter {

   protected AtomicInteger index = new AtomicInteger();
   protected AtomicLongArray items;

   public static final int DEFAULT_SAMPLE_SIZE = 128;

   /**
    * The default constructor.
    */
   public PerfAvg() {
      items = new AtomicLongArray(DEFAULT_SAMPLE_SIZE);
      initializeArray(items);
   }

   /**
    * Resizes the samples size to save. This will remove all the existing data
    * and reset the array. This method is not considered thread safe but since
    * it's not called often or only on initialize we still allow it.
    * 
    * @param sampleSize
    *           The size of the new sample to hold in memory.
    */
   public void setSampleSize(int sampleSize) {
      AtomicLongArray newArray = new AtomicLongArray(sampleSize);
      initializeArray(newArray);
      items = newArray;
      index.set(0);
   }

   public int getSampleSize() {
      return items.length();
   }

   private void initializeArray(AtomicLongArray initArray) {
      for (int i = 0; i < initArray.length(); i++) {
         initArray.set(i, Long.MIN_VALUE);
      }
   }

   /**
    * The display value of average as formatted by the supplied format string.
    */
   @Override
   public String getDisplayValue() {

      // Java formatters are not considered thread-safe
      // therefore we must synchronize access
      synchronized (formatter) {
         return formatter.format(getRawDoubleValue());
      }
   }

   /**
    * Adds a value to the sample. Increments the index and adds the value to the
    * array.
    * 
    * Under high load some samples may be missed. Increasing the sampleSize
    * decreases the chance a sample will be missed.
    * 
    * @param raw
    *           The value to add into the sample
    */
   public void addValue(long raw) {

      int tempIndex = index.incrementAndGet();

      if (tempIndex <= items.length()) {
         items.set(tempIndex - 1, raw);
      }
      else {
         tempIndex = index.getAndSet(0);
         // If this thread won it should be zero.
         if (tempIndex == 0) {
            index.incrementAndGet();
            items.set(0, raw);
         }
         else {
            // recursion makes the most sense so we
            // don't miss any values something like
            // addValue(raw) but in reality missing
            // a sample or two is better than the
            // recursion endlessly looping.
            // If the method is hammered so hard we went
            // threw the array twice then missing samples
            // is the least of our worries.
            tempIndex = index.incrementAndGet();

            if (tempIndex <= items.length()) {
               items.set(tempIndex - 1, raw);
            }
         }
      }
   }

   /**
    * Returns the sample values array size. The array length can be shorter than
    * the set sample size if enough data hasn't been captured yet.
    */
   @Override
   public long[] getRawSample() {

      long raw = 0;
      int i = 0;

      long[] raws = new long[items.length()];

      for (i = 0; i < items.length(); i++) {
         raw = items.get(i);

         if (raw != Long.MIN_VALUE)
            raws[i] = raw;
         else {
            break;
         }
      }

      if (i < raws.length) {
         long[] rawsTemp = new long[i];
         System.arraycopy(raws, 0, rawsTemp, 0, i);
         raws = rawsTemp;
      }

      return raws;
   }

   /**
    * See {@link #getAvg()}
    */
   @Override
   public double getRawDoubleValue() {
      return getAvg();
   }

   /**
    * {#link getRawSample} is preferred. This is only a copy of the long[] data.
    */
   @Override
   public double[] getRawDoubleSample() {
      return convertRawSample(getRawSample());
   }

   /**
    * {#link getRawDoubleValue} is preferred. This is casted from that value and
    * may loose some information.
    */
   @Override
   public long getRawLongValue() {
      return (long) getAvg();
   }

   /**
    * returns the average of all the data added to the sample size.
    */
   public double getAvg() {

      double sum = 0;
      long raw = 0;
      int i = 0;

      for (i = 0; i < items.length(); i++) {
         raw = items.get(i);

         if (raw != Long.MIN_VALUE)
            sum += raw;
         else
            break;
      }

      return i == 0 ? 0 : sum / i;
   }

}
