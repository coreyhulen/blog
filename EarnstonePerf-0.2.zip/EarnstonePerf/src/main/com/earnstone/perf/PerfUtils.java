/*
 * EarnstonePerf: Java Simple Performance Counter toolkit.
 * 
 * Copyright 2010 Corey Hulen, Earnstone Corporation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package com.earnstone.perf;

public final class PerfUtils {

   public static final String NA = "NA";
   public static final long MILLIS_SEC = 1000;
   public static final long MILLIS_MIN = 60 * MILLIS_SEC;
   public static final long MILLIS_HOUR = 60 * MILLIS_MIN;
   public static final long MILLIS_DAY = 24 * MILLIS_HOUR;

   public static String getTimeSince(long period) {
      long days = period / MILLIS_DAY;
      period = period - (days * MILLIS_DAY);
      long hours = period / MILLIS_HOUR;
      period = period - (hours * MILLIS_HOUR);
      long minutes = period / MILLIS_MIN;
      period = period - (minutes * MILLIS_MIN);
      long seconds = period / MILLIS_SEC;

      StringBuilder displayString = new StringBuilder(32);

      if (days != 0)
         displayString.append(days).append(" days");

      if (hours != 0 || displayString.length() > 0) {
         if (displayString.length() > 0)
            displayString.append(' ');
         displayString.append(hours).append(" hrs");
      }

      if (minutes != 0 || displayString.length() > 0) {
         if (displayString.length() > 0)
            displayString.append(' ');
         displayString.append(minutes).append(" m");
      }

      if (seconds != 0 || displayString.length() > 0) {
         if (displayString.length() > 0)
            displayString.append(' ');
         displayString.append(seconds).append(" s");
      }

      if (displayString.length() == 0)
         displayString.append("0 s");

      return displayString.toString();
   }
  
}
