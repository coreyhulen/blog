/*
 * EarnstonePerf: Java Simple Performance Counter toolkit.
 * 
 * Copyright 2010 Corey Hulen, Earnstone Corporation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package com.earnstone.perf;

import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * The base class implementation for Java performance counters. All the
 * underlying performance counters are inherited from this class. Every class
 * inherited from PerfCounter should be considered thread-safe. Category, Name
 * and description will never be <code>null</code>, but may be the empty string.
 * 
 * @author Corey Hulen
 */
public abstract class PerfCounter implements Comparable<PerfCounter> {

   private String category;
   private String name;
   private String description;

   protected NumberFormat formatter = new DecimalFormat(FORMAT_DEFAULT);;
   public static final String FORMAT_DEFAULT = "0.##";

   /**
    * The default constructor sets initial values to the empty string.
    */
   public PerfCounter() {
   }

   /**
    * Sets the human readable display name for the performance counter. Once the
    * name is set it cannot be changed.
    * 
    * @param name
    *           The human readable display name for the performance counter. If
    *           null then sets the name to the empty string.
    */
   public void setName(String name) {      
      if (name == null || name.length() == 0)
         throw new IllegalArgumentException();
      
      if (this.name == null)
         this.name = name;      
   }

   /**
    * The human readable display name for the performance counter.
    */
   public String getName() {
      return name;
   }

   /**
    * Sets the human readable display name for the performance counter.
    * 
    * @param description
    *           The human readable display name for the performance counter. If
    *           null then sets the description to the empty string.
    */
   public void setDescription(String description) {
      if (description == null)
         this.description = "";
      else
         this.description = description;
   }

   /**
    * The human readable display name for the performance counter.
    */
   public String getDescription() {
      return description;
   }

   /**
    * Sets the human readable category for the performance counter. Once the
    * category is set it cannot be changed.
    * 
    * @param category
    *           The human readable display name for the performance counter. If
    *           null then sets the category to the empty string.
    */
   public void setCategory(String category) {
      if (category == null || category.length() == 0)
         throw new IllegalArgumentException();
      
      if (this.category == null)
         this.category = category;
   }

   /**
    * The human readable category name for the performance counter.
    */
   public String getCategory() {
      return category;
   }

   /**
    * Sets the format string to use.
    * 
    * @param formatter
    *           A format string that is used to construct a DecimalFormat. If
    *           null is supplied then we will use the default format string.
    *           derived classes may override the default implementation.
    */
   public synchronized void setFormatter(String formatter) {
      if (formatter == null || formatter.length() == 0)
         this.formatter = new DecimalFormat(FORMAT_DEFAULT);
      else
         this.formatter = new DecimalFormat(formatter);
   }

   /**
    * The value from {@link #getDisplayValue()}
    */
   @Override
   public String toString() {
      return getDisplayValue();
   }

   /**
    * The human readable display value. The human readable display value.
    * Sub-classes should format with descriptive information like '9.85
    * gets/sec' or '3 hrs 22 mins'
    */
   public abstract String getDisplayValue();
 
   /**
    * The raw value of the underlying data. How to interpret this raw
    * information is dependent on the sub-class.
    */
   public abstract long getRawLongValue();
   
   /**
    * The raw value of the underlying data. How to interpret this raw
    * information is dependent on the sub-class.
    */
   public abstract double getRawDoubleValue();

   /**
    * The raw value of the underlying data. How to interpret this raw
    * information is dependent on the sub-class. Raw sample can return an empty
    * array signifying that raw sample is not used.
    */
   public abstract long[] getRawSample();
   
   /**
    * The raw value of the underlying data. How to interpret this raw
    * information is dependent on the sub-class. Raw sample can return an empty
    * array signifying that raw sample is not used.
    */
   public abstract double[] getRawDoubleSample();   

   @Override
   public int compareTo(PerfCounter base) {

      int catComp = category.compareTo(base.category);

      if (catComp == 0)
         return name.compareTo(base.name);
      else
         return catComp;
   }
   
   protected double[] convertRawSample(long[] ins) {
      double[] outs = new double[ins.length];
      
      for (int i = 0; i < outs.length; i++)
         outs[i] = (double)ins[i];
      
      return outs;
   }
}
