/*
 * EarnstonePerf: Java Simple Performance Counter toolkit.
 * 
 * Copyright 2010 Corey Hulen, Earnstone Corporation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package com.earnstone.perf;

/**
 * A performance counter for calls per second over a time sample. The big
 * difference between this class and its base <code>PerfCounterAvg</code> are
 * some convenience methods to display the results as calls per second (or
 * minutes, hours, etc). The class also has some convenience methods for getting
 * calls per milli, second, minute, hour, and day. This class is considered
 * thread-safe. If there are more calls to <code>incrementCall()</code> than the
 * sample size with in the <code>PerTime</code> then the value returns 'NA' or
 * essentially its too fast increase the sample size buffer. Meaning if I have a
 * sample size of 10 with <code>PerTime.Sec</code> set and I
 * <code>incrementCall</code> more than 10 times in a second then the results
 * cannot be calculated. We only know you are at 10+ request per second (so we show
 * NA).
 * 
 * @author Corey Hulen
 * 
 */
public class PerfAvgCallsPerSec extends PerfAvg {

   public enum PerTime {
      Sec, Min, Hour, Day
   }

   protected PerTime perTime;
   protected long perTimeMulti;
   
   public static final String FORMAT_PER_SEC = "0.## per sec";
   public static final String FORMAT_PER_MIN = "0.## per min";
   public static final String FORMAT_PER_HOUR = "0.## per hour";
   public static final String FORMAT_PER_DAY = "0.## per day";

   /**
    * The default constructor.
    */
   public PerfAvgCallsPerSec() {
      setPerTime(PerTime.Sec);
   }

   /**
    * Sets the PerTime enum used to calculate the Calls Per Second (or Minute,
    * Hour, etc). Setting this will also re-set the formatter. If you have a
    * custom formatter it must be reset after this call.
    */
   public void setPerTime(PerTime perTime) {
      this.perTime = perTime;

      if (perTime == PerTime.Day) {
         perTimeMulti = PerfUtils.MILLIS_DAY;
         this.setFormatter(FORMAT_PER_DAY);
      }
      else if (perTime == PerTime.Hour) {
         perTimeMulti = PerfUtils.MILLIS_HOUR;
         this.setFormatter(FORMAT_PER_HOUR);
      }
      else if (perTime == PerTime.Min) {
         perTimeMulti = PerfUtils.MILLIS_MIN;
         this.setFormatter(FORMAT_PER_MIN);
      }
      else {
         perTimeMulti = PerfUtils.MILLIS_SEC;
         this.setFormatter(FORMAT_PER_SEC);
      }
   }

   /**
    * Returns the PerTime enum used to calculate the Calls Per Second (or
    * Minute, Hour, etc).
    */
   public PerTime getPerTime() {
      return perTime;
   }

   /**
    * Returns the calls per second (or minute, hour, etc) depending on the
    * <code>PerTime</code> configuration. The default formatters will look like
    * '14.35 per sec' or '344.55 per min'
    */
   @Override
   public String getDisplayValue() {

      double value = getCallsPer();

      if (value == Double.MIN_VALUE)
         return PerfUtils.NA;
      else if (value == Double.MAX_VALUE)
         return "Cannot be measured (too fast)";
      else {
         // Java formatters are not considered thread-safe
         // therefore we must synchronize access
         synchronized (formatter) {
            return formatter.format(value);
         }
      }
   }

   /**
    * A convenience method for adding the current time to the underlying array.
    * Internally it calls <code>addValue</code> from the base class.
    */
   public void incrementCall() {
      addValue(System.currentTimeMillis());
   }
 
   /**
    * See {@link #getCallsPer()}
    */
   @Override
   public double getRawDoubleValue() {
      return getCallsPer();
   }

   /**
    * returns number of calls per time specified.
    */
   public double getCallsPer() {

      double minCount = 0;
      long max = Long.MIN_VALUE;
      long min = Long.MAX_VALUE;

      for (int i = 0; i < items.length(); i++) {
         long raw = items.get(i);

         if (raw == Long.MIN_VALUE)
            minCount++;
         else {
            max = Math.max(max, raw);
            min = Math.min(min, raw);
         }
      }

      if (minCount == items.length())
         return Double.MIN_VALUE;

      double period = (double) (max - min) / perTimeMulti;

      if (period <= 0)
         return Double.MAX_VALUE;
      else
         return (double) (items.length() - minCount) / period;
   }
}
