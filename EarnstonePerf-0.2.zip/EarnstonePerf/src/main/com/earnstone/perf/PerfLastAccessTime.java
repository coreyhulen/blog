/*
 * EarnstonePerf: Java Simple Performance Counter toolkit.
 * 
 * Copyright 2010 Corey Hulen, Earnstone Corporation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
package com.earnstone.perf;

/**
 * A performance counter for displaying last access time. The big difference
 * between this class and its base <code>PerfCounterCount</code> are some
 * convenience methods to display the results as time. This will display time as
 * '12 days 12 hrs 22 m 14 s'. Great for counters like last access time or up
 * time. This class is considered thread-safe.
 * 
 * @author Corey Hulen
 * 
 */
public class PerfLastAccessTime extends PerfIncrement {

   /**
    * The default constructor.
    */
   public PerfLastAccessTime() {
      count.set(Long.MIN_VALUE);
   }

   /**
    * The display value of raw count as formatted by the supplied format string.
    */
   @Override
   public String getDisplayValue() {

      if (count.get() == Long.MIN_VALUE)
         return PerfUtils.NA;
      else
         return PerfUtils.getTimeSince(System.currentTimeMillis() - count.get());
   }

   /**
    * A convenience method to set the current value to
    * <code>System.currentTimeMillis()</code>.
    */
   public void updateLastAccess() {
      set(System.currentTimeMillis());
   }
}
